(function installOzonStoreScannerCore(globalScope) {
  function cleanText(value) {
    return String(value ?? "").replace(/\r/g, "").trim();
  }

  const SHIPPING_RISK_RULES = Object.freeze([
    { id: "weapons", type: "suspected_prohibited", label: "枪支弹药 / 管制刀具 / 兵器武器", keywords: ["枪支", "枪械", "弹药", "子弹", "管制刀具", "军刀", "兵器", "武器"] },
    { id: "dangerous-goods", type: "suspected_prohibited", label: "易燃易爆 / 气罐 / 灭火器 / 氟利昂", keywords: ["易燃", "易爆", "瓦斯罐", "煤气罐", "燃气罐", "灭火器", "氟利昂"] },
    { id: "drugs", type: "suspected_prohibited", label: "毒品及吸毒工具", keywords: ["毒品", "吸毒工具", "冰壶", "吸毒壶"] },
    { id: "radioactive-military", type: "suspected_prohibited", label: "放射性 / 军用及间谍装备", keywords: ["放射性", "军用装备", "间谍装备", "军用窃听"] },
    { id: "restricted-media", type: "suspected_prohibited", label: "涉黄涉政宗教书刊影像", keywords: ["色情", "成人影像", "涉政", "宗教书刊", "宗教影像"] },
    { id: "heritage", type: "suspected_prohibited", label: "文化遗产物品", keywords: ["文化遗产", "文物", "古董原件"] },
    { id: "agrochemicals", type: "suspected_prohibited", label: "农药及农用化学品 / 除草剂", keywords: ["农药", "农用化学品", "除草剂", "杀虫剂原液"] },
    { id: "bio-agriculture", type: "suspected_prohibited", label: "种子 / 土壤 / 饲料", keywords: ["种子", "土壤", "饲料"], exceptions: ["种子收纳", "种子盒", "土壤检测仪", "土壤测试仪", "饲料勺", "饲料桶"] },
    { id: "fishing", type: "suspected_prohibited", label: "捕鱼工具 / 渔网", keywords: ["捕鱼工具", "捕鱼器", "渔网", "撒网", "捕捞网", "电鱼"] },
    { id: "animal-equipment", type: "suspected_prohibited", label: "牲畜挤奶器 / 蛋孵化器", keywords: ["挤奶器", "挤奶机", "蛋孵化器", "孵蛋器"] },
    { id: "living-organisms", type: "suspected_prohibited", label: "动物植物 / 骸骨及骨灰", keywords: ["活体动物", "活体植物", "宠物活体", "苗木", "动物骸骨", "人类骸骨", "骨灰"] },
    { id: "cash-tobacco", type: "suspected_prohibited", label: "现金 / 烟草及烟具", keywords: ["现金", "烟草", "电子烟", "烟油", "水烟壶", "水烟管", "烟斗"] },
    { id: "food-medicine", type: "suspected_prohibited", label: "食品 / 药品 / 保健品 / 茶叶 / 酒精", keywords: ["食品", "药品", "保健品", "茶叶", "酒精", "白酒", "红酒", "啤酒"], exceptions: ["食品收纳", "食品包装", "食品夹", "食品级", "药品收纳", "药盒", "茶叶罐", "茶具", "酒精测试仪", "酒精棉盒"] },
    { id: "restricted-meters", type: "suspected_prohibited", label: "汞温度计 / 万用表 / 剂量计 / 编程器 / 汽车诊断仪 / 辐射探测仪", keywords: ["汞温度计", "水银温度计", "万用表", "剂量计", "编程器", "汽车诊断仪", "辐射探测仪"], exceptions: ["万用表表笔", "万用表测试线", "万用表保护套", "编程器外壳", "诊断仪收纳", "探测仪保护套"] },
    { id: "controlled-machinery", type: "suspected_prohibited", label: "雕刻机 / 无人机 / 矿机", keywords: ["雕刻机", "无人机", "矿机"], exceptions: ["雕刻机配件", "雕刻机夹具", "无人机收纳", "无人机保护", "无人机支架", "无人机配件", "矿机风扇", "矿机电源"] },
    { id: "vehicles-engine", type: "suspected_prohibited", label: "发动机 / 燃油摩托车 / 电动车 / 电动滑板车", keywords: ["发动机", "燃油摩托车", "电动车整车", "电动滑板车"], exceptions: ["发动机胶垫", "发动机支架", "发动机护板", "发动机滤芯", "发动机垫", "发动机配件", "电动车配件", "滑板车配件"] },
    { id: "precision-medical", type: "suspected_prohibited", label: "精密仪器 / 医疗牙科美容设备 / 穿刺针", keywords: ["精密仪器", "医疗机器", "医疗设备", "牙科材料", "牙科器械", "美容院线仪器", "穿刺针"] },
    { id: "surveillance", type: "suspected_prohibited", label: "隐藏摄像 / 干扰跟踪录音设备", keywords: ["隐藏摄像头", "针孔摄像头", "信号干扰器", "GPS跟踪器", "GPS追踪器", "录音笔"] },
    { id: "theft-infringement", type: "suspected_prohibited", label: "偷盗工具 / 侵权产品 / 商业用品", keywords: ["万能钥匙", "开锁器", "偷盗工具", "侵权产品", "仿牌", "高仿", "复刻版", "商业用品"] },
    { id: "pneumatic-hydraulic", type: "land_only", label: "气压 / 液压工具（仅限陆运）", keywords: ["气压", "气动", "液压"] },
    { id: "empty-lighter", type: "land_only", label: "无汽无油打火机（仅限陆运）", keywords: ["无汽打火机", "无气打火机", "无油打火机", "空打火机", "打火机外壳"] },
    { id: "lighter", type: "suspected_prohibited", label: "打火机（需确认无汽无油）", keywords: ["打火机"] },
  ]);

  function normalizeRiskText(value) {
    return cleanText(value).toLocaleLowerCase("zh-CN").replace(/\s+/g, "");
  }

  function classifyShippingRisk(rawText) {
    const text = normalizeRiskText(rawText);
    if (!text) return { type: "clear", ruleId: "", label: "", matchedKeyword: "" };
    for (const rule of SHIPPING_RISK_RULES) {
      const keyword = rule.keywords.find((entry) => text.includes(normalizeRiskText(entry)));
      if (!keyword) continue;
      const excepted = (rule.exceptions || []).some((entry) => text.includes(normalizeRiskText(entry)));
      if (excepted) continue;
      return { type: rule.type, ruleId: rule.id, label: rule.label, matchedKeyword: keyword };
    }
    return { type: "clear", ruleId: "", label: "", matchedKeyword: "" };
  }

  function productShippingRisk(product = {}) {
    const stored = product.shippingRisk;
    if (stored?.type && stored.type !== "clear") return stored;
    return classifyShippingRisk(`${cleanText(product.category)}\n${cleanText(product.name)}\n${cleanText(product.rawRiskText)}`);
  }

  function shippingReviewLabel(product = {}) {
    const risk = productShippingRisk(product);
    if (risk.type === "land_only") return "仅限陆运";
    if (risk.type !== "suspected_prohibited") return "正常";
    if (product.shippingReviewDecision === "allowed") return "已允许找品";
    if (product.shippingReviewDecision === "excluded") return "已确认排除";
    return "待人工复核";
  }

  function productAllowedForTaskQueue(product = {}) {
    const risk = productShippingRisk(product);
    return risk.type !== "suspected_prohibited" || product.shippingReviewDecision === "allowed";
  }

  function createSerializedExecutor() {
    let queue = Promise.resolve();
    return (operation) => {
      const result = queue.then(operation, operation);
      queue = result.catch(() => null);
      return result;
    };
  }

  function firstMatch(text, pattern) {
    return cleanText(text).match(pattern)?.[1]?.trim() || "";
  }

  function competitorState(rawText) {
    const text = cleanText(rawText);
    const hasLabel = /跟卖最低价\s*[:：]?/.test(text);
    if (!hasLabel) return { value: "", ready: false };
    const numeric = text.match(/跟卖最低价\s*[:：]?\s*([¥￥₽]?[ \t]*[0-9][0-9 \t\u00a0\u202f.,]*)/);
    if (numeric?.[1]) return { value: numeric[1].trim(), ready: true };
    const empty = text.match(/跟卖最低价\s*[:：]?\s*(无|暂无|没有跟卖|--|—|-)(?=\s|$)/);
    if (empty?.[1]) return { value: empty[1], ready: true };
    return { value: "", ready: false };
  }

  function sellerKeyFromUrl(url) {
    try {
      const parsed = new URL(url);
      return parsed.pathname.match(/^\/seller\/([^/]+)/i)?.[1] || "";
    } catch {
      return "";
    }
  }

  function normalizeSellerUrl(value) {
    const input = cleanText(value).replace(/^<|>$/g, "");
    if (!input) return "";
    try {
      const parsed = new URL(/^https?:\/\//i.test(input) ? input : `https://${input}`);
      if (!/(^|\.)ozon\.ru$/i.test(parsed.hostname)) return "";
      const sellerKey = sellerKeyFromUrl(parsed.href);
      return sellerKey ? `https://www.ozon.ru/seller/${sellerKey}/` : "";
    } catch {
      return "";
    }
  }

  function parseStoreUrlList(rawText, maxStores = 50) {
    const urls = [];
    const invalid = [];
    const seen = new Set();
    let duplicateCount = 0;
    let overflowCount = 0;
    const limit = Math.max(1, Number(maxStores) || 50);
    cleanText(rawText).split(/\n+/).map((line) => line.trim()).filter(Boolean).forEach((line) => {
      const url = normalizeSellerUrl(line);
      if (!url) {
        invalid.push(line);
        return;
      }
      const key = sellerKeyFromUrl(url);
      if (seen.has(key)) {
        duplicateCount += 1;
        return;
      }
      seen.add(key);
      if (urls.length >= limit) {
        overflowCount += 1;
        return;
      }
      urls.push(url);
    });
    return { urls, invalid, duplicateCount, overflowCount };
  }

  function canonicalProductLink(link) {
    try {
      const parsed = new URL(link);
      return `${parsed.origin}${parsed.pathname}`;
    } catch {
      return cleanText(link).split("?")[0];
    }
  }

  function parseCardText(rawText) {
    const text = cleanText(rawText);
    const commissionSection = text.match(/rFBS佣金：([\s\S]*?)SKU：/)?.[1] || "";
    const competitor = competitorState(text);
    return {
      qualified: /(?:^|\n)[ \t]*符合要求[ \t]*(?:\n|$)/.test(text),
      category: firstMatch(text, /类目：\s*([^\n]+)/),
      sku: firstMatch(text, /SKU：\s*(\d+)/),
      price: firstMatch(text, /(\d[\d\s\u00a0\u202f]*[,.]\d{2})\s*¥/),
      commissions: [...commissionSection.matchAll(/(\d+(?:[.,]\d+)?)\s*%/g)].map((match) => `${match[1]}%`).slice(0, 3),
      monthlySales: firstMatch(text, /月销量：\s*([^\n]+)/),
      fulfillment: firstMatch(text, /发货模式：\s*([^\n]+)/),
      dimensions: firstMatch(text, /长\s*宽\s*高：\s*([^\n]+)/),
      weight: firstMatch(text, /重\s*量：\s*([^\n]+)/),
      listedAt: firstMatch(text, /上架时间：\s*([^\n]+)/),
      competitor: competitor.value,
      competitorReady: competitor.ready,
    };
  }

  function markdownCell(value) {
    const text = cleanText(value).replace(/\n+/g, " ").replace(/\|/g, "\\|");
    return text || "-";
  }

  function safeFilePart(value) {
    return cleanText(value).replace(/[\\/:*?"<>|]+/g, "_").replace(/\s+/g, "_").slice(0, 60) || "Ozon店铺";
  }

  function csvCell(value) {
    let text = cleanText(value).replace(/\n+/g, " ");
    if (/^[=+\-@]/.test(text)) text = `'${text}`;
    return `"${text.replace(/"/g, '""')}"`;
  }

  function numericValue(value) {
    let text = cleanText(value).replace(/[¥￥₽%]/g, "").replace(/[\u00a0\u202f]/g, " ");
    const match = text.match(/-?[\d\s.,]+/);
    if (!match) return null;
    text = match[0].replace(/\s+/g, "");
    const comma = text.lastIndexOf(",");
    const dot = text.lastIndexOf(".");
    if (comma >= 0 && dot >= 0) {
      const decimal = comma > dot ? "," : ".";
      text = text.replace(new RegExp(`\\${decimal === "," ? "." : ","}`, "g"), "").replace(decimal, ".");
    } else if (comma >= 0) text = text.replace(",", ".");
    const parsed = Number(text);
    return Number.isFinite(parsed) ? parsed : null;
  }

  function dimensionsMm(value) {
    const values = [...cleanText(value).matchAll(/(\d+(?:[.,]\d+)?)/g)]
      .map((match) => numericValue(match[1]))
      .filter((entry) => entry !== null);
    return values.length >= 3
      ? { lengthMm: values[0], widthMm: values[1], heightMm: values[2] }
      : { lengthMm: null, widthMm: null, heightMm: null };
  }

  function weightGrams(value) {
    const amount = numericValue(value);
    if (amount === null) return null;
    return /kg|кг|千克|公斤/i.test(cleanText(value)) ? amount * 1000 : amount;
  }

  function selectedCommission(effectiveGreenPrice, commissions) {
    const price = Number(effectiveGreenPrice);
    if (!(price > 0)) return null;
    const tierIndex = price <= 600 ? 1 : 2;
    return Number.isFinite(commissions[tierIndex]) ? commissions[tierIndex] : null;
  }

  function batchStoreState(stores, sellerKey) {
    return stores?.[sellerKey] || { products: {} };
  }

  function storeResultStorageKey(sellerKey) {
    const key = cleanText(sellerKey);
    return key ? `ozonStoreQualifiedProductsV2:${encodeURIComponent(key)}` : "";
  }

  function mergeStoreState(existing = {}, incoming = {}) {
    const previousProducts = existing?.products || {};
    const incomingProducts = incoming?.products || {};
    const products = { ...previousProducts };
    Object.entries(incomingProducts).forEach(([sku, product]) => {
      const previous = previousProducts[sku] || {};
      const next = { ...previous, ...product };
      if (!product?.competitor && previous.competitor) {
        next.competitor = previous.competitor;
        next.competitorReady = previous.competitorReady;
      }
      products[sku] = next;
    });
    const observedSkus = [...new Set([...(existing?.observedSkus || []), ...(incoming?.observedSkus || [])].map(String).filter(Boolean))];
    return {
      ...existing,
      ...incoming,
      observedCount: observedSkus.length || Math.max(Number(existing?.observedCount) || 0, Number(incoming?.observedCount) || 0),
      observedSkus,
      pendingLinks: [...new Set((incoming?.pendingLinks || []).map(canonicalProductLink).filter(Boolean))],
      products,
    };
  }

  function mergeAttemptObservedSkus(existing = [], incoming = []) {
    return [...new Set([...existing, ...incoming].map(String).filter(Boolean))];
  }

  function batchProductRows(batch, stores) {
    const rows = [];
    (batch?.stores || []).forEach((task, storeIndex) => {
      const saved = batchStoreState(stores, task.sellerKey);
      const products = Object.values(saved.products || {}).sort((a, b) => String(a.sku || "").localeCompare(String(b.sku || ""), "zh-CN", { numeric: true }));
      if (!products.length) {
        rows.push({ task, saved, storeIndex, productIndex: -1, product: null });
        return;
      }
      products.forEach((product, productIndex) => rows.push({ task, saved, storeIndex, productIndex, product }));
    });
    return rows;
  }

  function batchStatusLabel(status) {
    return ({ pending: "等待中", loading: "正在打开", recovering: "刷新后恢复中", scanning: "扫描中", retrying: "等待重试", completed: "已完成", partial: "部分完成", failed: "失败", skipped: "已跳过", running: "运行中", paused: "已暂停", stopped: "已停止" })[status] || cleanText(status) || "等待中";
  }

  function buildBatchMarkdown({ batch, stores = {}, exportedAt }) {
    const tasks = batch?.stores || [];
    const productCount = tasks.reduce((sum, task) => sum + Object.keys(batchStoreState(stores, task.sellerKey).products || {}).length, 0);
    const lines = [
      "# Ozon 批量店铺“符合要求”商品清单", "",
      `- 批次编号：${markdownCell(batch?.id)}`,
      `- 导出时间：${cleanText(exportedAt)}`,
      `- 店铺数量：${tasks.length} 个`,
      `- 符合要求商品：${productCount} 个`,
      `- 批次状态：${batchStatusLabel(batch?.status)}`, "",
      "| 店铺序号 | 店铺 | 状态 | 商品序号 | 商品名称 | 类目 | SKU | 价格 | rFBS 佣金 | 月销量 | 发货模式 | 长宽高 | 重量 | 跟卖最低价 | 运输风险 | 处理状态 | 命中规则 | 商品链接 |",
      "| ---: | --- | --- | ---: | --- | --- | --- | ---: | --- | ---: | --- | --- | --- | ---: | --- | --- | --- | --- |",
    ];
    batchProductRows(batch, stores).forEach(({ task, saved, storeIndex, productIndex, product }) => {
      const storeLink = `[${markdownCell(saved.storeName || task.sellerKey)}](${task.url})`;
      if (!product) {
        lines.push(`| ${storeIndex + 1} | ${storeLink} | ${batchStatusLabel(task.status)} | - | 暂无符合要求的商品 | - | - | - | - | - | - | - | - | - | - | - | - | - |`);
        return;
      }
      const risk = productShippingRisk(product);
      lines.push(`| ${storeIndex + 1} | ${storeLink} | ${batchStatusLabel(task.status)} | ${productIndex + 1} | ${markdownCell(product.name)} | ${markdownCell(product.category)} | ${markdownCell(product.sku)} | ${markdownCell(product.price)} | ${markdownCell((product.commissions || []).join(" / "))} | ${markdownCell(product.monthlySales)} | ${markdownCell(product.fulfillment)} | ${markdownCell(product.dimensions)} | ${markdownCell(product.weight)} | ${markdownCell(product.competitor)} | ${markdownCell(risk.label || "正常")} | ${markdownCell(shippingReviewLabel(product))} | ${markdownCell(risk.matchedKeyword)} | [打开商品](${canonicalProductLink(product.link)}) |`);
    });
    lines.push("", "> 按批量任务中的店铺顺序汇总；只收录毛子 ERP 明确显示“符合要求”的商品。", "");
    return lines.join("\n");
  }

  function buildBatchCsv({ batch, stores = {} }) {
    const header = ["店铺序号", "店铺名称", "店铺地址", "扫描状态", "商品序号", "商品名称", "类目", "SKU", "价格", "rFBS佣金", "月销量", "发货模式", "长宽高", "重量", "跟卖最低价", "运输风险", "处理状态", "命中规则", "商品链接"];
    const lines = [header.map(csvCell).join(",")];
    batchProductRows(batch, stores).forEach(({ task, saved, storeIndex, productIndex, product }) => {
      const risk = product ? productShippingRisk(product) : {};
      const row = [storeIndex + 1, saved.storeName || task.sellerKey, task.url, batchStatusLabel(task.status), product ? productIndex + 1 : "", product?.name || "", product?.category || "", product?.sku || "", product?.price || "", (product?.commissions || []).join(" / "), product?.monthlySales || "", product?.fulfillment || "", product?.dimensions || "", product?.weight || "", product?.competitor || "", risk.label || "", product ? shippingReviewLabel(product) : "", risk.matchedKeyword || "", product ? canonicalProductLink(product.link) : ""];
      lines.push(row.map(csvCell).join(","));
    });
    return lines.join("\r\n");
  }

  function buildBatchTaskQueue({ batch, stores = {}, exportedAt, createdAt = new Date().toISOString() }) {
    const tasks = batchProductRows(batch, stores)
      .filter((entry) => entry.product && productAllowedForTaskQueue(entry.product))
      .map(({ task, saved, storeIndex, productIndex, product }) => {
        const pagePrice = numericValue(product.price);
        const competitorPrice = /无|暂无|没有跟卖|^[-—]+$/i.test(cleanText(product.competitor)) ? null : numericValue(product.competitor);
        const effectiveGreenPrice = [pagePrice, competitorPrice]
          .filter((entry) => Number(entry) > 0)
          .sort((a, b) => a - b)[0] ?? null;
        const commissions = (product.commissions || [])
          .map(numericValue)
          .filter((entry) => entry !== null);
        const size = dimensionsMm(product.dimensions);
        return {
          taskId: `ozon-${cleanText(product.sku)}`,
          status: "pending_ozon_enrichment",
          source: {
            batchId: cleanText(batch?.id),
            exportedAt: cleanText(exportedAt) || createdAt,
            batchStatus: batchStatusLabel(batch?.status),
            storeIndex: storeIndex + 1,
            storeName: cleanText(saved.storeName || task.sellerKey),
            storeUrl: task.url,
            storeStatus: batchStatusLabel(task.status),
            productIndex: productIndex + 1,
          },
          qualification: {
            status: "qualified",
            source: "batch_store_scan",
            verifiedAt: cleanText(exportedAt) || createdAt,
          },
          ozon: {
            sku: cleanText(product.sku),
            name: cleanText(product.name),
            category: cleanText(product.category),
            productUrl: canonicalProductLink(product.link),
            pagePrice,
            competitorPrice,
            effectiveGreenPrice,
            commissions,
            selectedCommission: selectedCommission(effectiveGreenPrice, commissions),
            monthlySales: numericValue(product.monthlySales),
            fulfillment: cleanText(product.fulfillment),
            ...size,
            weightG: weightGrams(product.weight),
            shippingRestriction: (() => {
              const risk = productShippingRisk(product);
              return risk.type === "land_only" ? { type: "land_only", label: risk.label, matchedKeyword: risk.matchedKeyword } : null;
            })(),
          },
          enrichment: {
            status: "pending",
            mainImageUrl: null,
            originalBlackPrice: null,
            blackPriceSourceUrl: null,
            internationalFreight: null,
            freightRoute: null,
            maxPurchaseCostAt18Pct: null,
          },
          sourcing: {
            platform: "pinduoduo",
            status: "pending",
            candidates: [],
            selectedCandidate: null,
            judgeProvider: null,
            judgeResult: null,
          },
          pricing: {
            purchaseCost: null,
            sourceUrl: null,
            profit: null,
            profitMargin: null,
            eligibleAt18Pct: null,
          },
          audit: { createdAt, updatedAt: createdAt },
        };
      });
    const batchSummary = {
      batchId: cleanText(batch?.id),
      exportedAt: cleanText(exportedAt) || createdAt,
      status: batchStatusLabel(batch?.status),
      declaredStoreCount: (batch?.stores || []).length,
      declaredProductCount: tasks.length,
    };
    return {
      schemaVersion: 1,
      generatedAt: createdAt,
      batch: batchSummary,
      summary: {
        parsedProductCount: tasks.length,
        storeCount: new Set(tasks.map((entry) => entry.source.storeUrl || entry.source.storeName)).size,
        pendingEnrichmentCount: tasks.length,
        excludedShippingRiskCount: batchProductRows(batch, stores).filter((entry) => entry.product && !productAllowedForTaskQueue(entry.product)).length,
      },
      selection: { strategy: "all", count: tasks.length },
      tasks,
    };
  }

  function assessViewportReadiness(visibleLinks = [], loadedByLink = new Map()) {
    const loaded = loadedByLink instanceof Map ? loadedByLink : new Map(Object.entries(loadedByLink || {}));
    const links = [...new Set(visibleLinks.map(canonicalProductLink).filter(Boolean))].sort();
    const missingLinks = links.filter((link) => !loaded.has(link) || loaded.get(link)?.ready === false);
    const signature = links.map((link) => `${link}=${loaded.has(link) ? JSON.stringify(loaded.get(link)) : "pending"}`).join("|");
    return {
      visibleCount: links.length,
      loadedCount: links.length - missingLinks.length,
      missingLinks,
      signature,
    };
  }

  function shouldAutoSkipStore(observedCount, qualifiedCount, observedThreshold = 1000, qualifiedLimit = 3) {
    return Number(observedCount) >= Number(observedThreshold) && Number(qualifiedCount) < Number(qualifiedLimit);
  }

  function autoSkipDisposition(observedCount, qualifiedCount, zeroMatchThreshold = 500, lowYieldThreshold = 1000, lowYieldLimit = 3) {
    const observed = Math.max(0, Number(observedCount) || 0);
    const qualified = Math.max(0, Number(qualifiedCount) || 0);
    if (observed >= Number(zeroMatchThreshold) && qualified === 0) {
      return { code: "zero-match-500", observedThreshold: Number(zeroMatchThreshold), qualifiedLimit: 1 };
    }
    if (observed >= Number(lowYieldThreshold) && qualified < Number(lowYieldLimit)) {
      return { code: "low-yield-1000", observedThreshold: Number(lowYieldThreshold), qualifiedLimit: Number(lowYieldLimit) };
    }
    return null;
  }

  function classifyStoreFinish({ reviewing = false, forwardReachedBoundary = false, pendingCount = 0 } = {}) {
    const pending = Math.max(0, Number(pendingCount) || 0);
    if (reviewing && forwardReachedBoundary && pending === 0) {
      return { status: "completed", complete: true, note: "已完成（省略剩余反向复查）" };
    }
    if (pending > 0) {
      return { status: "partial", complete: false, note: `部分完成：仍有${pending}个商品待复查` };
    }
    return { status: "skipped", complete: false, note: "提前结束当前店（保留已找到商品）" };
  }

  function removeBatchStoreTask(batch, sellerKey) {
    if (!batch || !Array.isArray(batch.stores)) return { removed: null, index: -1, wasCurrent: false };
    const index = batch.stores.findIndex((task) => task.sellerKey === sellerKey);
    if (index < 0) return { removed: null, index: -1, wasCurrent: false };
    const wasCurrent = index === batch.currentIndex;
    const [removed] = batch.stores.splice(index, 1);
    if (index < batch.currentIndex) batch.currentIndex -= 1;
    else if (wasCurrent) batch.currentIndex = Math.min(index, batch.stores.length);
    return { removed, index, wasCurrent };
  }

  function buildMarkdown({ storeName, storeUrl, exportedAt, products = [], observedCount = 0, scanComplete = false }) {
    const sorted = [...products].sort((a, b) => String(a.sku || "").localeCompare(String(b.sku || ""), "zh-CN", { numeric: true }));
    const lines = [
      `# ${cleanText(storeName) || "Ozon 店铺"}“符合要求”商品清单`,
      "",
      `- 店铺地址：<${cleanText(storeUrl)}>`,
      `- 导出时间：${cleanText(exportedAt)}`,
      `- 已识别店铺商品：${Number(observedCount) || 0} 个`,
      `- 符合要求：${sorted.length} 个`,
      `- 扫描状态：${scanComplete ? "已到达店铺商品末尾" : "阶段性结果，扫描尚未确认完成"}`,
      "",
      "| 序号 | 商品名称 | 类目 | SKU | 价格 | rFBS 佣金 | 月销量 | 发货模式 | 长宽高 | 重量 | 跟卖最低价 | 运输风险 | 处理状态 | 命中规则 | 商品链接 |",
      "| ---: | --- | --- | --- | ---: | --- | ---: | --- | --- | --- | ---: | --- | --- | --- | --- |",
    ];
    if (!sorted.length) {
      lines.push("| - | 暂无符合要求的商品 | - | - | - | - | - | - | - | - | - | - | - | - | - |");
    } else {
      sorted.forEach((product, index) => {
        const risk = productShippingRisk(product);
        lines.push(`| ${index + 1} | ${markdownCell(product.name)} | ${markdownCell(product.category)} | ${markdownCell(product.sku)} | ${markdownCell(product.price)} | ${markdownCell((product.commissions || []).join(" / "))} | ${markdownCell(product.monthlySales)} | ${markdownCell(product.fulfillment)} | ${markdownCell(product.dimensions)} | ${markdownCell(product.weight)} | ${markdownCell(product.competitor)} | ${markdownCell(risk.label || "正常")} | ${markdownCell(shippingReviewLabel(product))} | ${markdownCell(risk.matchedKeyword)} | [打开商品](${canonicalProductLink(product.link)}) |`);
      });
    }
    lines.push("", "> 只收录毛子 ERP 商品卡片中明确显示“符合要求”标签的商品；“您可能喜欢”区域不计入店铺结果。", "");
    return lines.join("\n");
  }

  globalScope.OzonStoreScannerCore = Object.freeze({
    assessViewportReadiness,
    autoSkipDisposition,
    buildBatchCsv,
    buildBatchMarkdown,
    buildBatchTaskQueue,
    buildMarkdown,
    canonicalProductLink,
    classifyShippingRisk,
    classifyStoreFinish,
    cleanText,
    competitorState,
    createSerializedExecutor,
    csvCell,
    markdownCell,
    parseCardText,
    parseStoreUrlList,
    removeBatchStoreTask,
    safeFilePart,
    productAllowedForTaskQueue,
    productShippingRisk,
    sellerKeyFromUrl,
    storeResultStorageKey,
    mergeAttemptObservedSkus,
    mergeStoreState,
    shouldAutoSkipStore,
    shippingReviewLabel,
    normalizeSellerUrl,
  });
})(globalThis);
